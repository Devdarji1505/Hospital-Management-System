package patientinfo;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;

import org.sqlite.SQLiteConnection;

public class Newuser extends JFrame {

    // Generated serial version ID
    private static final long serialVersionUID = 1L;

    // Components declaration
    private JPanel contentPane;
    private JTextField newusername;
    private JTextField newpassword;
    private static final String DATABASE_URL= "jdbc:sqlite:D:\\Brunel\\group project all documnent\\new loginpage data.db";
    // Main method to run the program
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    // Create and display the frame
                    Newuser frame = new Newuser();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    // Constructor for the Newuser frame
    public Newuser() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1184, 718);
        contentPane = new JPanel();
        contentPane.setBackground(new Color(0, 0, 0));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Username text field
        newusername = new JTextField();
        newusername.setFont(new Font("Tahoma", Font.PLAIN, 20));
        newusername.setBounds(416, 312, 192, 45);
        contentPane.add(newusername);
        newusername.setColumns(10);

        // Password text field
        newpassword = new JTextField();
        newpassword.setFont(new Font("Tahoma", Font.PLAIN, 20));
        newpassword.setForeground(new Color(0, 0, 0));
        newpassword.setBounds(416, 422, 192, 45);
        contentPane.add(newpassword);
        newpassword.setColumns(10);

        // Register button
        JButton register = new JButton("Register");
        register.setBorder(new LineBorder(new Color(255, 255, 255), 3, true));
        register.setBackground(new Color(0, 0, 0));
        register.setForeground(new Color(255, 255, 255));
        register.setFont(new Font("Tahoma", Font.PLAIN, 30));
        register.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	String username=newusername.getText();
            	String password =newpassword.getText();
            	// Check if both username and password are entered
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(contentPane, "Please enter both username and password");}
                else {
                	// save user data to databse
                	saveUserData();
                }
            	// Create a new instance of Loginpage frame
                Loginpage logi = new Loginpage();
                logi.setVisible(true);
                 
                dispose();
                
				
            }
        });
        register.setBounds(416, 528, 192, 45);
        contentPane.add(register);
        
        // Hospital label
        JLabel lblNewLabel = new JLabel("      Brunel Multi-Speciality Hospital");
        lblNewLabel.setIcon(new ImageIcon("D:\\Brunel\\group project all documnent\\medical-hospital-flat-icon-on-260nw-555407245.jpg"));
        lblNewLabel.setForeground(new Color(0, 255, 255));
        lblNewLabel.setFont(new Font("Arial", Font.BOLD, 40));
        lblNewLabel.setBounds(10, 10, 1036, 135);
        contentPane.add(lblNewLabel);
        
        // New User Login label
        JLabel lblNewLabel_1 = new JLabel("               New User Login");
        lblNewLabel_1.setForeground(new Color(0, 255, 255));
        lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 30));
        lblNewLabel_1.setBounds(293, 155, 377, 56);
        contentPane.add(lblNewLabel_1);
        
        // Username label
        JLabel lblNewLabel_2 = new JLabel("Username");
        lblNewLabel_2.setForeground(new Color(255, 255, 255));
        lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_2.setBounds(413, 257, 163, 45);
        contentPane.add(lblNewLabel_2);
        
        // Password label
        JLabel lblNewLabel_2_1 = new JLabel("Password");
        lblNewLabel_2_1.setForeground(Color.WHITE);
        lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
        lblNewLabel_2_1.setBounds(413, 367, 163, 45);
        contentPane.add(lblNewLabel_2_1);
    }

    // Method to save user data to the database
    private void saveUserData() { 
    	
    	  
    
    		
    	
        try {
        	
       
            // Establish database connection
            Connection connection = DriverManager.getConnection(DATABASE_URL);
            // SQL query to insert user data
            String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                // Set values for the prepared statement
                statement.setString(1, newusername.getText());
                statement.setString(2, newpassword.getText());
                // Execute the insert statement
                statement.executeUpdate();
            }
            // close the datatbase
            connection.close();
            JOptionPane.showMessageDialog(contentPane, "User successfully register❤️😍");
           
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(contentPane, "Error👎");
        }
    }
}
